/**
 * 
 */
package section1;

/**
 * @author roddy
 *
 */
public interface MyGenericContainerInterface<T> {
	T getContained();
}
