/**
 * 
 */
package section2;

/**
 * @author roddy
 *
 */
public interface HasName {

	public String getName();
}
