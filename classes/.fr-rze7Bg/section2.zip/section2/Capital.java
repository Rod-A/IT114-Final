/**
 * 
 */
package section2;

/**
 * @author roddy
 *
 */
public class Capital implements HasName {
	
	private String name;
	
	public Capital(String name){
		
		this.name = name;
		
	}
	
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
