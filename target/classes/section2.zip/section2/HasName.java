/**
 * 
 */
package section2;

/**
 * @author kamran
 *
 */
public interface HasName {

	public String getName();
}
