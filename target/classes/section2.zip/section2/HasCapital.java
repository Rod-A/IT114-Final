/**
 * 
 */
package section2;

/**
 * @author kamran
 *
 */
public interface HasCapital<C extends Capital> {
	
	public C getCaptial();
	public String getCapitalName();
}
