/**
 * 
 */
package section1;

/**
 * @author kamran
 *
 */
public interface MyGenericContainerInterface<T> {
	T getContained();
}
